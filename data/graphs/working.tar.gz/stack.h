#ifndef STACK_H_
#define STACK_H_

#include<stdlib.h>

int push(void *);
void *pop();
size_t stack_count();

#endif
